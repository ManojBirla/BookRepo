package com.nt.constant;

public class AppConstants {

	/**
	 * for key of message
	 */
	public static final String succMsgKey="regsucc";
	public static final String failMsgKey="regfail";
	
	public static final String EditAttribute="student";
	/**
	 * logical view name for student registration
	 */
	public static final String viewName="StudentForm";
	
	public static final String viewStudentData="ViewAllStudent";

	public static final String editStudentData="EditStudent";
	
	
	public static final String listOfStudents="studentList";
	
}
